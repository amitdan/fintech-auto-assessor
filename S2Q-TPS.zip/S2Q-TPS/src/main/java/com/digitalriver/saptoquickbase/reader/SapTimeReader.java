package com.digitalriver.saptoquickbase.reader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.digitaltariver.data.exchange.context.ApplicationContext;
import com.digitaltariver.data.exchange.declaration.Reader;
import com.digitaltariver.data.exchange.exception.ReadException;
import com.digitaltariver.data.exchange.service.ApplicationProperties;

/**
 * Reader class to read data from source and returns read object to caller
 * method. Implements {@link Reader}.
 *
 *
 */
public class SapTimeReader implements Reader {
	
	private static final Logger logger = LoggerFactory.getLogger(SapTimeReader.class);
    
	/**
	 * Method to read from the source. This method is automatically called by
	 * the DataTransferService Framework.
	 *
	 * @param context
	 *            - {@link ApplicationContext}
	 * @return Read object.
	 * @throws ReadException
	 *             - If something goes wrong.
	 */
	@Override
	public Object read(final ApplicationContext context) throws ReadException {

		SapTimeReader.logger.info("Starting reading operation.");

		List<String> sapTimeEntryBeanList = new ArrayList<String>();

		try {
			
			sapTimeEntryBeanList = Detect.argsHelper(System.out);
			if (sapTimeEntryBeanList.size() == 0) {
				SapTimeReader.logger
						.info("Could not proceed as we received 0 valid time entry from SAP");
			}
		} catch (final Exception e) {
			SapTimeReader.logger.info("Read Service failed........");
			throw new ReadException("Exception occured while reading from SAP",
					e);
		}
		SapTimeReader.logger.info("Reading operation over.");		
		return sapTimeEntryBeanList;
	}
	
	/**
	 * Check if logged hours are non empty or non zero.
	 *
	 * @param loggedHours
	 *            - String value - logged hours.
	 *            
	 * @return boolean value - true if hours is non empty or non zero, else false.
	 *
	 */
	private boolean isValidLoggedHours(final String loggedHours) {
		boolean isInvalidLoggedHours = true;
		if (StringUtils.equals(loggedHours, "0") || StringUtils.equals(loggedHours, "0.0") || StringUtils.isEmpty(loggedHours)) { 
			isInvalidLoggedHours = false;
		}
		return isInvalidLoggedHours;
	}
	
	/**
	 * Get SAP report name.
	 *
	 * @return String - sapReportName
	 */
	private String getSapReportName() {
		final String sapReportName = getSapReportStartDate() + "-" + getSapReportEndDate() + ".xls"; 
		return sapReportName;
	}
	
	/**
	 * Get Sap report start date string.
	 *
	 * @return String - dateString
	 */
	private String getSapReportStartDate() {
		return getDateString(-7);
	} 
	
	/**
	 * Get Sap report end date string.
	 *
	 * @return String - dateString
	 */
	private String getSapReportEndDate() { 
		return getDateString(-1);
	}
	
	/**
	 * Get date string per given date offset.
	 * 
	 * @param dateOffset - int value.
	 *
	 * @return String - dateString
	 */
	private String getDateString(int dateOffset) {
		Calendar c = Calendar.getInstance();
		c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);
		c.add(Calendar.DATE, dateOffset);
		final String year = Integer.toString(c.get(Calendar.YEAR));
		final String month = String.format("%02d", c.get(Calendar.MONTH) + 1);
		final String day = String.format("%02d", c.get(Calendar.DATE));
		final String dateString = year + month + day;
		return dateString;
	}
}