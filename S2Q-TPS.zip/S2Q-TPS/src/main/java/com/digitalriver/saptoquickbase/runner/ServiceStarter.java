
package com.digitalriver.saptoquickbase.runner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.digitaltariver.data.exchange.exception.ApplicationFailException;
import com.digitaltariver.data.exchange.service.ApplicationRunner;

/**
 * Service Starter class which is responsible to start Sap to Quickbase 
 * Time Pushing service
 *
 *
 */
public class ServiceStarter {

	private static final Logger logger = LoggerFactory.getLogger(ServiceStarter.class);

	/**
	 * Constant for property file name
	 */
	public static final String PROPERTY_FILE_NAME = "Application.properties";
	
	/**
	 * Constant for property file name
	 */
	public static final String EXTERNAL_PROPERTY_FILE_PATH = "externalPropertyFilePath";

	/**
	 * Main method which is responsible to start Sap to Quickbase Time Pushing Service 
	 *
	 * @throws ApplicationFailException
	 *             - If application fails to start.
	 */
	public static void main(String args[]) throws ApplicationFailException {
		final String externalPropertyFilePath = System.getProperties().getProperty(EXTERNAL_PROPERTY_FILE_PATH);
		final ServiceStarter strt = new ServiceStarter();
		strt.run(externalPropertyFilePath);
	}

	/**
	 * Method that loads the property file and calls run() method of
	 * ApplicationRunner
	 *
	 * @param externalPropertyFile
	 *            - String value - External property file
	 *
	 * @throws ApplicationFailException
	 *             - If application fails to start.
	 */
	public void run(final String externalPropertyFilePath) throws ApplicationFailException {
		InputStream inputStream = null;
		try {
			if (StringUtils.isNotBlank(externalPropertyFilePath)) {
				final File propFile = new File(externalPropertyFilePath);
				if (propFile.exists() && !propFile.isDirectory()) {
					inputStream = new FileInputStream(propFile);
					ServiceStarter.logger.info("Using system file as properties file to initialize context");
				}
			} else {
				inputStream = getClass().getClassLoader().getResourceAsStream(ServiceStarter.PROPERTY_FILE_NAME);
				ServiceStarter.logger.info("Using properties file from Jar to initialize context");
			}
			final ApplicationRunner runner = new ApplicationRunnerImpl(inputStream);
			runner.run();
		} catch (final FileNotFoundException e) {
			throw new ApplicationFailException("Error while reading external properties file", e);
		}
	}
}
