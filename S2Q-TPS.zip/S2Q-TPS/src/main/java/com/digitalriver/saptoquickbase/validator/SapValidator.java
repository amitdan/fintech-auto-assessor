package com.digitalriver.saptoquickbase.validator;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.digitaltariver.data.exchange.context.ApplicationContext;
import com.digitaltariver.data.exchange.declaration.Validator;
import com.digitaltariver.data.exchange.exception.ValidatorException;
import com.digitaltariver.data.exchange.service.ApplicationProperties;

/**
 * Java class to validate Sap properties.
 *
 * Implements from {@link Validator}.
 *
 */
public class SapValidator implements Validator {

	protected static final Logger logger = LoggerFactory.getLogger(SapValidator.class);

	/**
	 * Method to validate Sap properties.This method is automatically
	 * called by the DataTransferService Framework.
	 *
	 * @param context
	 *            - {@link ApplicationContext}
	 * @throws ValidatorException
	 *             - If validation Fails.
	 */
	@Override
	public void validate(final ApplicationContext context) throws ValidatorException {

		SapValidator.logger.info("---------------------------------------------------------------------------------");
		SapValidator.logger.info("..Started Sap Properties Validation operation ...................................");
		SapValidator.logger.info("---------------------------------------------------------------------------------");

		SapValidator.logger.info("---------------------------------------------------------------------------------");
		SapValidator.logger.info("..Validation operation finish........");
		SapValidator.logger.info("----------------------------------------------------------------------------");
	}
}