package com.digitalriver.saptoquickbase.writer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.digitalriver.saptoquickbase.quickbase.api.QuickbaseApi;
import com.digitaltariver.data.exchange.context.ApplicationContext;
import com.digitaltariver.data.exchange.declaration.Writer;
import com.digitaltariver.data.exchange.exception.WriteException;
import com.digitaltariver.data.exchange.service.ApplicationProperties;

/**
 * Java class to write actual hours into Quickbase task
 *
 * Implements from {@link Writer}.
 *
 */
public class QuickbaseWriter implements Writer {
	
	/**
	 * Logger instance
	 */
	private static final Logger logger = LoggerFactory.getLogger(QuickbaseWriter.class);

	/**
	 * Method to write source object to the destination.
	 *
	 * @param context
	 *            - {@link ApplicationContext}
	 * @param destObject
	 *            - Object to be written to the destination.
	 * @throws WriteException
	 *             - If something goes wrong while writing.
	 */
	@Override
	public void write(final ApplicationContext context, final Object destObject) throws WriteException {
		final List<String> beans = (List<String>) destObject;
		try {
			if (beans != null && beans.size() > 0) {
				QuickbaseWriter.logger.info("Writing operation begins.");
				generateReport(context, beans);
				QuickbaseWriter.logger.info("Writing operation finished.");				
			} else {
				QuickbaseWriter.logger.info("Skipping write operation as we have not recieved valid entries to write.");	
			}
		} catch (final Exception e) {
			QuickbaseWriter.logger.info("Writing operation failed........");
			throw new WriteException(
					"Exception occured while writing to Quickbase", e);
		} 
	}
	
	private void generateReport(final ApplicationContext context, final List<String> beans) throws WriteException {
        final XSSFWorkbook workbook = new XSSFWorkbook(); 
        final XSSFSheet sheet = workbook.createSheet("Report");
        int rownum = 1;
        final Row headerRow = generateHeaderRow(sheet);
        for (String key : beans)
        {
        	final Row row = sheet.createRow(rownum++);
            String[] arr = key.split(":");
            final Cell cell1 = row.createCell(0);
            cell1.setCellValue(arr[0]);
            final Cell cell2 = row.createCell(1);
            cell2.setCellValue(arr[1]);

        }
            FileOutputStream out = null;
			try {
				out = new FileOutputStream(new File(getReportName()));
				workbook.write(out);
	            out.close();
			} catch (FileNotFoundException e) {
				throw new WriteException(
						"Exception occured while writing to Xls Report", e);
			} catch (IOException e) {
				throw new WriteException(
						"Exception occured while writing to Xls Report", e);
			}
    }	
	
	private String getReportName() {
		final DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		final Date dateobj = new Date();
		final String fileName = "REPORT_NAME"
				+ df.format(dateobj) + ".xlsx";
		return fileName;
	}
	
	private Row generateHeaderRow(final XSSFSheet sheet) {
        final Map<String, Object[]> data = new TreeMap<String, Object[]>();
        data.put("1", new Object[] {"COLUMN NAME", "COLUMN VALUE"});
        Row row = null;  
        final Set<String> keyset = data.keySet();
        for (String key : keyset)
        {
            row = sheet.createRow(0);
            final Object [] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr)
            {
               final Cell cell = row.createCell(cellnum++);
               cell.setCellValue((String)obj);
            }
        }
        return row;
    }
}