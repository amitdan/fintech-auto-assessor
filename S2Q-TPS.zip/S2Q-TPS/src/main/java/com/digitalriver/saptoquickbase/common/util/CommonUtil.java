package com.digitalriver.saptoquickbase.common.util;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

/**
 * Common utility class 
 *
 */
public class CommonUtil {

	/**
	 * Returns array as list per given separator string
	 *
	 * @param srcString
	 *            - Source string having comma separated values
	 * @return list of string. - {@link List<String>}
	 *
	 */
	public List<String> getArrayAsList(final String srcString, final char separator) {
		String array[] = StringUtils.split(srcString, separator);
		List<String> list = Arrays.asList(array);
		return list;
	}
}