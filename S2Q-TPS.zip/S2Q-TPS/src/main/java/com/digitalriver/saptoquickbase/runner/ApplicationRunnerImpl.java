package com.digitalriver.saptoquickbase.runner;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.digitaltariver.data.exchange.context.ApplicationContext;
import com.digitaltariver.data.exchange.exception.ApplicationFailException;
import com.digitaltariver.data.exchange.service.ApplicationRunner;

/**
 * Application runner implementation class to redefine the definition of the
 * doStart and doFinish primitive method
 *
 * Extends from {@link ApplicationRunner}.
 *
 */
public class ApplicationRunnerImpl extends ApplicationRunner {

	/**
	 * Logger instance
	 */
	private static final Logger logger = LoggerFactory.getLogger(ApplicationRunnerImpl.class);

	/**
	 * Parameterized constructor to create the instance.
	 *
	 * @param inStream
	 *            - the input stream of the properties file
	 * @throws ApplicationFailException
	 *             - If application failes to initialize.
	 */
	public ApplicationRunnerImpl(InputStream inStream) throws ApplicationFailException {
		super(inStream);
	}

	/**
	 * Method to log job details before starting it's ecxecution. First
	 * primitive method to be called by run method.
	 *
	 * @param context
	 *            - {@link ApplicationContext}
	 */
	@Override
	public void doStart(final ApplicationContext context) {
		logger.info("---------------------------------------------------------------------------------");
		logger.info("-------------------SAP TO QUICKBASE TIME PUSHING SERVICE-------------------------");
		logger.info("---------------------------------------------------------------------------------");
		logger.info("---------------------------------------------------------------------------------");
		logger.info("Starting Sap to Quickbase Time Pushing service with below properties: ");

		for (Entry<Object, Object> entry : context.getProperties().getProperties().entrySet()) {
			logger.info(entry.toString());
		}
		logger.info("---------------------------------------------------------------------------------");
		logger.info("---------------------------------------------------------------------------------");
	}

	/**
	 * Method to log job statistics like number of stories created after job
	 * execution. Last primitive method to be called by run method.
	 *
	 * @param context
	 *            - {@link ApplicationContext}
	 */
	@Override
	public void doFinish(final ApplicationContext context) {
		logger.info("---------------------------------------------------------------------------------");
		logger.info("---------------------------------------------------------------------------------");
		logger.info("Time Pushing service Complete....");
		logger.info("=================================================================================");
		logger.info("--- Job Summary :");
		final Map mapElement = (Map) context;
		
		ArrayList loggableKeyList = new ArrayList();
		
		final Iterator beanEntries = mapElement.entrySet().iterator();
		while (beanEntries.hasNext()) {
			final Entry thisEntry = (Entry) beanEntries.next();
			if(loggableKeyList.contains(thisEntry.getKey())) {
				logger.info(thisEntry.toString());
			}
		}
		logger.info("=================================================================================");
		logger.info("---------------------------------------------------------------------------------");
		logger.info("---------------------------------------------------------------------------------");
	}
}
