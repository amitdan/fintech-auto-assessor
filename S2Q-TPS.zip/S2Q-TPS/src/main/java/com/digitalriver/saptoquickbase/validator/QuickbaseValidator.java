package com.digitalriver.saptoquickbase.validator;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.digitaltariver.data.exchange.context.ApplicationContext;
import com.digitaltariver.data.exchange.declaration.Validator;
import com.digitaltariver.data.exchange.exception.ValidatorException;
import com.digitaltariver.data.exchange.service.ApplicationProperties;

/**
 * Java class to validate Quickbase properties.
 *
 * Implements from {@link Validator}.
 *
 *
 */
public class QuickbaseValidator implements Validator {

	protected static final Logger logger = LoggerFactory.getLogger(QuickbaseValidator.class);

	/**
	 * Method to validate Quickbase properties.This method is automatically
	 * called by the DataTransferService Framework.
	 *
	 * @param context
	 *            - {@link ApplicationContext}
	 * @throws ValidatorException
	 *             - If validation Fails.
	 */
	@Override
	public void validate(final ApplicationContext context) throws ValidatorException {

		QuickbaseValidator.logger.info("---------------------------------------------------------------------------------");
		QuickbaseValidator.logger.info("..Started Quickbase Properties Validation operation ........");
		QuickbaseValidator.logger.info("---------------------------------------------------------------------------------");

		QuickbaseValidator.logger.info("---------------------------------------------------------------------------------");
		QuickbaseValidator.logger.info("..Validation operation finish........");
		QuickbaseValidator.logger.info("----------------------------------------------------------------------------");
	}
}