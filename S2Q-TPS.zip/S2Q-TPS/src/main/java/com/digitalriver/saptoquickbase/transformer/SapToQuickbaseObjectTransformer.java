
package com.digitalriver.saptoquickbase.transformer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.digitalriver.saptoquickbase.quickbase.api.QuickbaseApi;
import com.digitaltariver.data.exchange.context.ApplicationContext;
import com.digitaltariver.data.exchange.declaration.Transformer;
import com.digitaltariver.data.exchange.exception.TransformException;
import com.digitaltariver.data.exchange.service.ApplicationProperties;

/**
 * Java class to transform sap time entry details to Quickbase compatible format
 * 
 * Implements from {@link Transformer}.
 * 
 * 
 */
public class SapToQuickbaseObjectTransformer<V> implements Transformer {

	private static final Logger logger = LoggerFactory.getLogger(SapToQuickbaseObjectTransformer.class);

	Map qbAndSapTeamNameMapping = new HashMap();

	Map qbTaskIdMap = new HashMap();

	Map qbColumnNameMap = new HashMap();
	List<String> qBTasksMissingWBS = new ArrayList<String>();//CREATE ARRAY LIST
	int count = 0;

	/**
	 * Method to transform read object into writable object.
	 * 
	 * @param appContext
	 *            - {@link ApplicationContext}
	 * @param srcObject
	 *            - Read Object
	 * @return Transformed Object.
	 * @throws TransformException
	 *             - if something goes wrong while transformation.
	 */
	@Override
	public Object transform(final ApplicationContext appContext,final Object srcObject) throws TransformException {
		final List<String> sapTimeEntryBeans = (List<String>) srcObject;
		Map taskAndHoursMap = new HashMap();
		try {
			if (sapTimeEntryBeans != null && sapTimeEntryBeans.size() > 0) {
				SapToQuickbaseObjectTransformer.logger.info("Starting Transformation operation.");
				System.out.println("555"+sapTimeEntryBeans);
				//taskAndHoursMap = this.transform(appContext, sapTimeEntryBeans);
				SapToQuickbaseObjectTransformer.logger.info("Finished Transformation operation.");
			}else {
				SapToQuickbaseObjectTransformer.logger.info("Skipping transform operation as we nave not recieved valid entries to transform.");
			}
		} catch (final Exception e) {
			SapToQuickbaseObjectTransformer.logger.info("Transformation Service failed........");
			throw new TransformException("Exception occured while trasforming data from SAP to Quickbase",e);
		}
		return sapTimeEntryBeans;
	}

	/**
	 * 
	 * @param qBTasksMissingWBS
	 */
	private void logWBSTasksMissingQBID(List<String> qBTasksMissingWBS) {
		if(!qBTasksMissingWBS.isEmpty()) {
			SapToQuickbaseObjectTransformer.logger.info("WBS for which QB task was not found : "+ qBTasksMissingWBS.toString());
		}
	}

	

	/**
	 * Get quickbase task details matching sap wbs id.
	 * 
	 * @param properties
	 *            - {@link ApplicationProperties}
	 * 
	 * @param sapWbsId
	 *            - String - Sap wbs id
	 * 
	 * @return Vector - Quickbase task details vector
	 */
	private Vector getQuickbaseTaskDetails(final ApplicationProperties properties, final String sapWbsId) throws Exception {
		Vector qbTaskDetailsVector = new Vector();
		if (!this.qbTaskIdMap.containsKey(sapWbsId)) {
			//final QuickbaseApi qbApi = new QuickbaseApi();
			//qbTaskDetailsVector = qbApi.getQBTask(properties, sapWbsId);
			this.qbTaskIdMap.put(sapWbsId, qbTaskDetailsVector);
		} else {
			qbTaskDetailsVector = (Vector) this.qbTaskIdMap.get(sapWbsId);
		}

		if (qbTaskDetailsVector.size() == 0) {
			SapToQuickbaseObjectTransformer.logger.info("Not found QB tasks(s) associated with Wbs Element >> "+ sapWbsId);
			qBTasksMissingWBS.add(sapWbsId);						
		} else {
			SapToQuickbaseObjectTransformer.logger.info("QB tasks(s) details associated with Wbs Element "+ sapWbsId + " are " + qbTaskDetailsVector);
		}
		return qbTaskDetailsVector;
	}

	/**
	 * Method to get Qb actual hours column name per given qb team name.
	 * 
	 * @param qbTeamName
	 *            - Quickbase team name
	 * 
	 * @return String - Qb actual hours column name.
	 */
	private String getQbActualHoursColumnName(final String qbTeamName) {
		final String qbColumnName = (String) this.qbColumnNameMap.get(qbTeamName);
		return qbColumnName;
	}
}